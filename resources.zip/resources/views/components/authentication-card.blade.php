<div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-white dark:bg-gray-900">
    {{-- <div>
        {{ $logo }}
    </div> --}}

    <div class="w-full sm:max-w-md px-8 py-8 border bg-white dark:bg-gray-800 overflow-hidden sm:rounded-lg">
        {{ $slot }}
    </div>
</div>
